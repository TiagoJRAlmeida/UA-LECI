alert("Malicious script loaded. Muhahahahahahahahahahahaha!");
